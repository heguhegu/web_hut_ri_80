document.addEventListener('DOMContentLoaded', function () {
    const toggleButton = document.getElementById('toggle-milestones');
    const milestonesContainer = document.getElementById('milestones-container');

    toggleButton.addEventListener('click', function () {
        // Check if the container is hidden
        if (milestonesContainer.style.display === 'none') {
            milestonesContainer.style.display = 'block';
            toggleButton.textContent = 'Sembunyikan Milestone';
        } else {
            milestonesContainer.style.display = 'none';
            toggleButton.textContent = 'Lihat Milestone Penting';
        }
    });
});